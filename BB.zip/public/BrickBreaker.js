class BrickBreaker{
    constructor(){
        this.game;
        //this.menu = new Menu;
    }
    
    setGame(width, height){
        this.game = new Game(width, height);
    }
    
}