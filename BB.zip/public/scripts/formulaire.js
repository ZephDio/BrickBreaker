class Contact {
  constructor(email, username, password, confirmepassword) {
    this.email = email;
    this.username = username;
  }

  setPassword(password, confirmpassword) {
    if (password === confirmpassword) {
      this.password = password;
    }
  }

  isContactValid() {
    let namelength = this.username.length;
    if (namelength <= 3) {
      console.log("Username is too short");
      return false;
    } else if (namelength > 14) {
      console.log("Username is too long");
      return false;
    }
    for (const charactere of this.username) {
      if (charactere === " ") {
        console.log("space inside Username unallowed");
        return false;
      }
    }
    if (this.password === undefined) {
      console.log("password not matching");
      return false;
    }
    console.log("valid");
    return true;
  }
}

new Vue({
  el: ".cardregister",
  data: {
    Username: "",
    email: "",
    Password: "",
    ConfirmPassword: "",
    phone: "",
  },

  methods: {
    createContact() {
      const contact = new Contact(this.email, this.Username);
      contact.setPassword(this.Password, this.ConfirmPassword);
      if (true) {
        const pendingOperation = window.fetch(
          "http://localhost:8000/register",
          {
            method: "POST",
            body: JSON.stringify({
              enculer: "vrai",
              enfoire: "false",
              bite: "danslecul",
              // email: contact.email,
              // username: contact.username,
              // password: contact.password,
            }),
          }
        );
        //   pendingOperation.then((rep) => {
        //     rep.text().then((value) => {
        //       console.log("kek2");
        //     });
        //   });
        // }
      }
    },
  },
});
