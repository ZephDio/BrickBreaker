// const http = require("http");
const fs = require("fs");
const path = require("path");
const bodyParser = require("body-parser");
// const server = http.createServer((req, res) => {
//   if (req.method === "GET") {
//     let requrl = req.url;
//     if (requrl === "/") {
//       requrl = "index.html";
//     }
//     console.log(requrl);
//     const filepath = path.join(__dirname, "../public", requrl);
//     const file = fs.readFileSync(filepath);
//     res.write(file);
//     res.end();
//   }
//   if (req.method === "POST") {
//   }
// });

const express = require("express");

const server = express();

server.use(bodyParser.urlencoded({ extended: true }));

server.use(express.static(path.join(__dirname, "..", "public")));

server.post("/register", (req, rep) => {
  console.log(req.body);
});
// server.get("/", (req, res) => {
//   const requrl = "index.html";
//   const filepath = path.join(__dirname, "../public", requrl);
//   const file = fs.readFileSync(filepath);
//   res.write(file);
//   res.end();
// });

// server.use((req, res, next) => {
//   console.log("request received");s
//   if (req.method === "GET") {
//     let requrl = req.url;
//     if (requrl === "/") {
//       requrl = "index.html";
//     }
//     console.log(requrl);
//     const filepath = path.join(__dirname, "../public", requrl);
//     const file = fs.readFileSync(filepath);
//     res.write(file);
//     res.end();
//   }
//   if (req.method === "POST") {
//     res.write("ok");
//     res.end();
//   }
//   next();
// });

server.listen(8000);
