class Menu{
    constructor(onStartGame){
        this.selected = "Start Game"
    }
    
    
    onGo(){
            return this.selected
    }
    
    onNext(){
        
    }
    
    onPrevious(){
        
    }
}